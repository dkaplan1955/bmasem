#' BMASEM 
#'
#' This function for estimate parameters for selected models by the Down and Up.
#' @param from.vars  the vector of names of independent variables. 
#' @param to.vars    the vector of names of dependent variables. 
#' @param data       a data frame to fit the SEM model.
#' @param OR         a number specifying the maximum ratio for excluding models in Occam's window.
#' @param method     a sequence of algorithms, "downup", "updown", "up", "down".
#' @param start.link a set of links for the starting model. If this is NA, a starting model is randomly selected.
#' @param ...  further arguments passed to or from other methods 
#' @return     BMASEM returns an object of class BMASEM.
#' parameters  labels identifying parameters in the SEM
#' namesfrom   the names of the indicators in paths 
#' namesto     the names of the outcomes in paths 
#' @details    Bayesian Model Averaing for Structural Equation Modeling (BMASEM) accounts for the model uncertainty in SEM by averraing over the best models 
#' accoring to the approximate posterior model probabilities. 
#' @export     
#' @examples
#' from.vars <- c("x1","x1","x2","x2","y1")
#' to.vars   <- c("y1","y2","y1","y2","y2")
#' start.link <- c(1, 0, 0, 1, 1) # an example
#' BMASEM(from.vars, to.vars, data=train, start.link=start.link) 
#'  
BMASEM <- function(from.vars, to.vars, data, OR=20, method="downup", start.link=NA, ...)
{
  # common functions ---------------------------------------------
  modelSpace <- function (...)
  {
    ## Check input error----------------------
    n=length(from.vars) # the number of the total paths in the saturated model
    
    if (n != length(to.vars))
    { error <- simpleError("Lengths of two vectors are not the same.")
      tryCatch(stop(error))
    }

    names.all <- names(data)
    uniq.x <- unique(from.vars)
    uniq.y <- unique(to.vars)
    
    if (sum(!(uniq.x %in% names.all)) + sum(!(uniq.y %in% names.all)) != 0)
    { error <- simpleError("Not match between from.vars/to.vars and variables' names in data.")
      tryCatch(stop(error))
    }
    ## End of Check input error----------------------
    
    print("Establishing the model space----------------")
    grid = rep(list(0:1), n)
    mod.space <- do.call(expand.grid, grid)
    names(mod.space) <- paste(to.vars,"ON",from.vars, sep = "")
    
    mod.space$bin.rep <- apply(mod.space,1,function(x) { total <- 0; for(i in 1:n) total = total + (2^i)^x[i]; return(total) })
    
    return(mod.space)
  }
  
  namesParam <- function (...)
  {
    y.vars <- unique(to.vars)
    regressions.names <- paste0(to.vars,"~", from.vars)
    intercepts.names  <- paste0(y.vars, "~1")
    variances.names   <- paste0(y.vars, "~~", y.vars)
    return(c(regressions.names, intercepts.names, variances.names))
  }
  
  modelNum <- function(...)
  {
    bin.rep <- 0
    for(i in 1:length(start.link)) {bin.rep = bin.rep + (2^i)^start.link[i]} 
    M.start <- which(mod.space$bin.rep == bin.rep)
  }
  
  fitSem <- function(model.row, ...) 
  {
    modelSem <- function(model.row, ...) #called by fitSem()
    {
      variances <- intercepts <- regressions <- NULL
      
      for(i in 1:length(y.vars)) 
      {
        space = mod.space[model.row, -ncol(mod.space)]
        y = y.vars[i]
        
        id.1 = which(to.vars == y & space == 1)
        id.0 = which(to.vars == y & space == 0)
        
        # regressions
        if(length(id.1) > 0)
          regressions <- c(regressions, paste(y, " ~ ", paste(from.vars[id.1], collapse = " + ")), "\n")
        
        if(length(id.0) > 0)
          regressions <- c(regressions, paste(y, " ~ ", paste("0*", from.vars[id.0], collapse = " + ")), "\n")
        
        # intercepts
        int <- ifelse ( length(id.1) > 0, " ~ 1", " ~ 0*1")
        intercepts <- c(intercepts, paste0(y, int), "\n")
        
        # variances
        var <- ifelse( length(id.1)  > 0, " ~~ ", " ~~ 1*") 
        variances <- c(variances, paste0(y, var, y), "\n")
        
      }##END for
      
      regressions.c <- paste(regressions, collapse="")
      intercepts.c <- paste(intercepts, collapse="")
      variances.c <- paste(variances, collapse="")
      model <- paste(regressions.c,intercepts.c,variances.c, collapse="")
      return(model)
      
    }##END function modelSem
    
    lavaan.model <- modelSem(model.row) # call a function to generate a lavaan model
    sem1 <- sem(lavaan.model,data=data) # fit the model 
    return(sem1)
  }##END function fitSem
  
  # once a model is accepted, keep it remained
  modelAccept <- function(fit.M, M, BIC.M, ...) 
  {
    # get coeff
    coefs <- round(coef(fit.M), 4)
    num <- match(names(coefs), parameters.names)
    parameters <- rep(0, length(parameters.names))
    parameters[num] <- coefs
    
    # get se
    se <- fit.M@Fit@se
    se.1 <- se[se!=0]
    ses <- rep(0, length(parameters.names))
    ses[num]<- se.1
    
    # add to matrix or vector
    A.coef  <<- rbind(A.coef, parameters)
    A.model <<- rbind(A.model, M)
    A.bic <<- rbind(A.bic, BIC.M)  
    A.se <<- rbind(A.se, ses)  
    A <<- unique(c(A,M))
  }

  # Tracker----------------------
  # Update tracker in the UP and Down
  print.it <- function(M, M0, BIC.M, BIC.M0, BIC.dif, ...) 
  {
    # Update tracker  
    count <<- count + 1
    BIC_all[M] <<- BIC.M
    BIC_all[M0] <<- BIC.M0
    
    if(count == 1) 
    {
      sink(file = "Track.out", append = F)
      
      print("#-------------------------------------------------------------------------#")
      print("#-------------------------------------------------------------------------#")
      print("#------------------STARTING THE UP/DOWN ALGORITHM-------------------------#")
      print("#-------------------------------------------------------------------------#")
      print("#-------------------------------------------------------------------------#")
      print("")
      print(paste("C = Set of starting models for Down : {", paste(C.start, collapse = ", "),"}", sep = ""))
      print(paste("UP = Set of starting models for UP  : {", paste(UP.start, collapse = ", ")," }", sep = ""))
      
      sink()
    }##END IF COUNT
    
    sink(file = "Track.out", append = F)
    
    print("#---------------------------------------------------------------------------#")
    print(paste("#-----------------------------",count,"-------------------------------------#",sep = ""))
    print("#---------------------------------------------------------------------------#")
    
    print(paste("M = MODEL SELECTED FROM C/UP:",M))
    print(mod.space[M, ])
    print(paste("M0 = SUB/SUP MODEL SELECTED FROM M:",M0))
    if(is.na(M0)) print("No SUB/SUP MODEL")
    else  print(mod.space[M0,])
    print("Computing value IN #4 of UP/Down algorithm")
    print(paste("BIC of M", round(BIC.M,3)))
    print(paste("BIC of M0", round(BIC.M0,3)))
    print(paste("BIC difference", round(BIC.dif,3)))
    print(paste("C = Updated set of Down models: {", paste(C, collapse = ", "),"}", sep = ""))
    print(paste("UP = Updated set of UP models: {", paste(UP, collapse = ", ")," }", sep = ""))
    print(paste("A = Updated set of acceptable models: {", paste(A, collapse = ", ")," }", sep = ""))
    print(paste("X = Updated set of rejected models: {", paste(X, collapse = ", ")," }", sep = ""))
    
    sink()
    
  }##END print.it

  # Down function
  Down <- function(...)
  {
    subMexclude <- function(M0.temp)
    {
      links.zero <- which(mod.space[M0.temp,] == 0) 

      if (length(links.zero) > 1)
        links.to.remove <- which(apply(mod.space[, links.zero], 1, sum)==0)
      else
        links.to.remove <- which(mod.space[, links.zero]==0) #links.zero is one -> vector
        
      X <<- unique(c(X, links.to.remove)) #add M0 and its submodels to X
      C <<- setdiff(C, links.to.remove) #exclude M0 and its submodels from C 
      #   A <<- setdiff(A, links.to.remove) #exclude M0 and its submodels from A
      UP <<- setdiff(UP, links.to.remove)#exclude M0 and its submodels from UP
    }
    
    # Run the Down-Algorithm --------------------------------------
    while(length(C) > 0) 
    {
      # initiate variables 
      BIC.dif <- BIC.M0 <- BIC.M <- M <- NA
      M0 <- NA # null model (avoid error in print.it())
      
      #--#1--# Select a model from C ---------------------------
      {if (is.na(M.start)) { M <- as.numeric(sample(C,1))  }
      else {M <- M.start; M.start <- NA}}
      
      ## Remove M from C
      C <<- C[-match(M,C)]
      
      #--#2--# Fit M to data -------------------------------
      
      ### sem model for M
      sem.M <- try(fitSem(M)) # fit the model 
      if (inherits(sem.M, "try-error"))
      {
        BIC.M <- -Inf
        X <<- unique(c(X,M))
        print(paste0("Warning: sem fitting of M failed, using a marginal likelihood of -Inf"))
        # Tracker
        print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
        next()    
      }
      
      BIC.M <- fitMeasures(sem.M)["bic"]
      
      #--#3--# Find submodels of M ------------------------------
      
      #possible links to remove to create submodel M0
      links.to.remove <- which(mod.space[M,] == 1) #position number instead of names
      
      #check whether submodels are an excluded model or accepted model
      {if (length(links.to.remove) > 1) #length=1 : Null model is submodel
      { 
        bin.numbers <- mod.space$bin.rep[M] - (2^links.to.remove - 1)
        model.numbers <- match(bin.numbers, mod.space$bin.rep)
        model.numbers <- model.numbers[is.na(match(model.numbers, c(X, A)))]
      }
      else {model.numbers = NULL}}
      
      # No submodel: length=0  (integer(0)) 
      if (length(model.numbers)==0) 
      { 
        UP <<- unique(c(UP, M))
        print(paste0("No submodel of M in C!!"))
        # Tracker
        print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
        next()
      }
      
      #--#4--# Fit M0 to data and Compare M0 to M -----------------------
      for (i in 1:length(model.numbers))  # run if sub-models exist
      {
        # randomly select M0
        M0 <- model.numbers[i]    
        
        # sem model for M0
        sem.M0 <- try(fitSem(M0)) # fit the model 
        if (inherits(sem.M0, "try-error"))
        {
          BIC.M0 <- -Inf
          X <<- unique(c(X,M0))
          print(paste("Warning: sem fitting of M0 failed, using a marginal likelihood of -Inf", sep = ""))
          # Tracker
          print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
          next()    
        }
        
        BIC.M0 <- fitMeasures(sem.M0)["bic"]
        
        # Comparisons
        BIC.dif <- BIC.M - BIC.M0 #cause BIC is postive value
        
        if(BIC.dif > log.c) 
        {
          print("Model M0 is preferred!!")
          if (is.na(match(M0,UP))) C <<- unique(c(C, M0)) #add M0 to C or UP
          X <<- unique(c(X, M))  #add M to X 
        }
        
        if(BIC.dif < -log.c) 
        {
          print("Model M is preferred!!")
          if (is.na(match(M,A))) modelAccept(sem.M, M, BIC.M) # add M and M's fit into A and results, respectively
          subMexclude(M0) # add M0 and all M0's submodels into X
        }
        
        if(BIC.dif >= -log.c & BIC.dif <= log.c) 
        {
          print("Model M and M0 are preferred!!")
          if (is.na(match(M,A))) modelAccept(sem.M, M, BIC.M) # add M and M's fit into A and results, respectively
          if (is.na(match(M0,UP))) C <<- unique(c(C, M0)) #add M0 to C or UP
        }
        # Tracker
        print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
        
      } #// End of For (model comparions)
    } #//End of While for Down Algorithm-------------------------------
  } # //End of Down function
  
  Up <- function(...)
  {
    while(length(UP) > 0) 
    {
      # initiate variables 
      BIC.dif <- BIC.M0 <- BIC.M <- M <- NA
      M0 <- NA # No super model (avoid error in print.it())
      
      #--#1--# Select a model from UP
      M <- as.numeric(sample(UP,1))
      
      ## Remove M from UP
      UP <<- UP[-match(M,UP)]
      
      #--#2--# Fit M to data -------------------------------
      ### sem model for M
      sem.M <- try(fitSem(M)) # fit the model 
      if (inherits(sem.M, "try-error"))
      {
        BIC.M <- -Inf
        X <<- unique(c(X,M))
        print(paste0("Warning: sem fitting of M failed, using a marginal likelihood of -Inf"))
        # Tracker
        print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
        next()    
      }
      
      BIC.M <- fitMeasures(sem.M)["bic"]
      
      #--#3--# Find supermodels of M
      
      #possible links to add to create supermodel M1
      links.to.add <- which(mod.space[M,] == 0) #position number instead of names
      
      #check whether each supmodel is an excluded model or accepted model
      if (length(links.to.add) > 0)
      { 
        bin.numbers <- mod.space$bin.rep[M] + (2^links.to.add - 1) #bin number 
        model.numbers <- match(bin.numbers, mod.space$bin.rep)
        model.numbers <- model.numbers[is.na(match(model.numbers, c(X, A)))]
      }
      else {model.numbers = NULL}
      
      # No supmodel: length=0  (integer(0)) 
      if (length(model.numbers)==0) 
      { 
        modelAccept(sem.M, M, BIC.M)
        print(paste0("No supmodel of M in UP"))
        # Tracker
        print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
        next()
      }
      
      #--#4--# Model comparison
      for (i in 1:length(model.numbers))# run if super-models exist
      {
        # randomly select M0
        M0 <- model.numbers[i]    
        
        # sem model for M0
        sem.M0 <- try(fitSem(M0)) # fit the model 
        if (inherits(sem.M0, "try-error"))
        {
          BIC.M0 <- -Inf
          X <<- unique(c(X,M0))
          print(paste("Warning: sem fitting of M1 failed, using a marginal likelihood of -Inf", sep = ""))
          # Tracker
          print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
          next()    
        }
        
        BIC.M0 <- fitMeasures(sem.M0)["bic"]
        
        # Comparisons
        BIC.dif <- BIC.M0 - BIC.M #cause BIC is positive
        
        if(BIC.dif < -log.c) 
        {
          print("Model M1 is preferred!!") #print "M1" instead of M0 to identify the UP
          UP <<- unique(c(UP, M0)) #add M1 to UP
        }
        
        if(BIC.dif > log.c) 
        {
          print("Model M is preferred!!")
          if (is.na(match(M,A))) modelAccept(sem.M, M, BIC.M) # add M and M's fit into A and results, respectively
          X <<- unique(c(X, M0)) # add M1 to X
        }
        
        if(BIC.dif >= -log.c & BIC.dif <= log.c) 
        {
          print("Model M and M1 are preferred!!")
          if (is.na(match(M,A))) modelAccept(sem.M, M, BIC.M) # add M and M's fit into A and results, respectively
          UP <<- unique(c(UP, M0)) #add M1 to UP
        }
        # Tracker
        print.it(M, M0, BIC.M, BIC.M0, BIC.dif) 
        
      } #// End of For (model comparions)
    } #//End of While for UP Algorithm---------------------------------------  
  }# // End of Up()  
  
  #1. Model space (BMASEM ver. 0.1 : up to 2^15)
  mod.space <- modelSpace(from.vars, to.vars) #data frame
  parameters.names <- namesParam(from.vars, to.vars) # vector
  M.start <- ifelse(sum(is.na(start.link))!=0, NA, modelNum(start.link))
  y.vars <- unique(to.vars)
  
  #2. Initiate variables for the up and down 
  ## the cut-off score for Occam's window
  log.c <- log(OR)
  
  ## for sem results of all Accepted models 
  A.model <- NULL
  A.coef <- NULL
  A.bic <- NULL
  A.se <- NULL
  
  ## Set a set of considering models 
  C.start <- C <- NULL
  # Keep this as a character for sample()

  ## Model for the up algorithm !Update later for method="updown"
  UP.start <- UP <- NULL
  
  ## Accepted model 
  A <- NULL
  
  ## the NULL model is excluded (No link)
  X <- 1

  # Tracker
  count <- 0 #for tracker
  BIC_all <- rep(0, nrow(mod.space)) 
  
  if (method == "downup")
  {
    C.start <- C <- as.character(c(2:nrow(mod.space))) 
    UP.start <- UP <- NULL
    
    # Call Down() 
    print("Start the Down algorithm----------")
    Down()
    print("End of the Down algorithm----------")
    
    # Call UP() 
    if (length(UP) > 0) 
    {
      print("Start the Up algorithm----------")
      X <- NULL
      UP <- as.character(UP) # to avoid an error of sample from the last numeric value
      Up()
      print("End of the Up algorithm----------")
    }
    else
    {
      print("No models in UP----------")
    }
    
  }

  # Tracker
  out.track <- data.frame(cbind(Model=1:nrow(mod.space)), BIC=BIC_all)
  write.csv(out.track, file="Model_BIC.csv", row.names=FALSE)
  
  # Model averaging--------------------------------------
  A.parameters <- data.frame(cbind(A.model, A.bic, A.coef, A.se ), row.names=NULL)
  names(A.parameters)<-c("model","bic", parameters.names, paste("se",parameters.names,sep="."))
  
  # unique data set and sort by BIC
  A.parameters <- unique(A.parameters)
  A.parameters.sort <- A.parameters[order(A.parameters$bic), ]
  
  # Select models using Occam's window again
  mbic <- A.parameters.sort$bic - min(A.parameters.sort$bic)
  A.select <- A.parameters.sort[mbic <= (log.c), ]

  print(c("The number of Accepted Models is ", nrow(A.select)))

  # Use vectors
  S.model <- A.select$model
  S.bic <- A.select$bic
  S.coef <- A.select[, 3:(2+length(parameters.names))]
  S.coef <- as.matrix(S.coef, nrow=dim(S.coef)[1], ncol=dim(S.coef)[2])
  
  S.se <- A.select[, (3+length(parameters.names)):dim(A.select)[2]]
  S.se <- as.matrix(S.se, nrow=dim(S.se)[1], ncol=dim(S.se)[2])
  
  # Posterior Model Probability  
  mbic <- S.bic - max(S.bic)
  pmp <- round(exp(-0.5 * mbic)/sum(exp(-0.5 * mbic)), 4)
  
  # Calculate average of coeff weighted by pmp
  (avg.parameters <- S.coef * pmp)
  {if (length(A) > 1) avg.para <- round(colSums(avg.parameters),4)
   else avg.para <- round(avg.parameters,4)}
  
  # Calculate SD of BMA
  w.s.se <- pmp * (S.se^2)
  w.s.dif.avg <- matrix(0, nrow=dim(S.coef)[1], ncol=dim(S.coef)[2])
  for (i in 1:dim(S.coef)[1])
  {
    w.s.dif.avg[i, ] <- pmp[i] * (S.coef[i,]-avg.para)^2   
  }
  sum.model <- w.s.se + w.s.dif.avg
  sum.parameters <- apply(sum.model, 2, sum)
  sd.para <- sqrt(sum.parameters)

  # Calculate prob of not E = 0 : $probneo
  S.prob.logic <- S.coef != 0 #a matrix
  S.prob <- pmp * S.prob.logic * 100
  probne0 <- apply(S.prob, 2, sum)
  
  # Create label which has not E = 0 : $label
  S.label <- apply(S.prob.logic, 1, function(x) parameters.names[x])
  {if (length(S.model) > 1) names(S.label) <- paste0("M", 1:length(S.model))
    else colnames(S.label) <- "M1"}
  
  # For the predictive interval : add for BMASEM ver. 2.0 -------------------------------
  ### separate x(exogenous) and y(endogenous) variables
  from.uniq <- unique(from.vars)
  to.y <- unique(to.vars)
  from.x <- from.uniq[-which(from.uniq %in% to.y)]
  
  ### for only last y variable
  last.y <- to.y[-which(to.y %in% from.uniq)]
  
  ### lm model to get residuals
  frml = formula(paste(last.y, paste(from.x, collapse="+"), sep="~"))
  lm.temp <- lm(frml, data=data)

  lm.df <- lm.temp$df.residual
  lm.mse <- (sum(lm.temp$residuals^2)) /lm.df

  X = cbind(const=1, as.matrix(data[, from.x]))
  lm.inv <- solve(t(X) %*% X)

  # Final results in a BMASEM class
  model <- paste0("Model", seq(1, length(S.model)))
  bmasem.model <- list(parameter=parameters.names, namesfrom=from.vars, namesto=to.vars, 
                       method=method, bic=S.bic, coefficients=S.coef, postmean=avg.para, 
                       postsd=sd.para, probne0=probne0, postprob=pmp, model=model, label=S.label,  
                       lm.df=lm.df, lm.mse=lm.mse, lm.inv=lm.inv)
  class(bmasem.model) = "BMASEM"

  return(bmasem.model)

}