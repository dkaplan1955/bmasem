#' train.RData for BMASEM
#'
#' train is a generated toy data as a model-averaging set
#' 
#'
#' @format train is a data frame with 200 rows and 4 variables:
#' \describe{
#'   \item{y1}{endogenous variable}
#'   \item{y2}{final endogenous variable}
#'   \item{x1}{exogenous variable}
#'   \item{x2}{exogenous variable}
#' }
#' @source
#' These data are generated as a toy data set for BMASEM
#' 
"train"