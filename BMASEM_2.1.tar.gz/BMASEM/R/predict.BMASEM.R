#' Model Predictions 
#'
#' predict.BMASEM predicts new final y observations for newdata from the results of model fitting function, BMASEM.
#' @param object  a model object (BMASEM) for which prediction is desired.
#' @param newdata a data frame which is used to predict y.
#' @param level   a predictive interval.
#' @param bma.model   a selected model for prediction: 0 for the BMASEM (averaged coef), 1 for the Model1 (the best model's coef), etc. 
#' @param ...  additional arguments affecting he predictions produced.
#' @return     a data set having predicted responses values and lower and upper predictive intervals for the final endogenous variable from the BMASEM for each observation in newdata.
#' @details    This function predicts the response resulting from the BMASEM from given data. 
#' @export
#' @examples
#' from.vars <- c("x1","x1","x2","x2","y1")
#' to.vars   <- c("y1","y2","y1","y2","y2")
#' start.link <- c(1, 0, 0, 1, 1) # an example
#' model <- BMASEM (from.vars, to.vars, data=train, start.link=start.link)
#' pred.y <- predict(model, test) 
#' pred.y$fit
#' pred.y$lwr
#' pred.y$upr 

# function
predict.BMASEM <- function(object, newdata, level=.90, bma.model=0,... )
{
  # Creat SEM matrix --------------------------------------------
  # separate x(exogenous) and y(endogenous) variables
  from.uniq <- unique(object$namesfrom)
  to.y <- unique(object$namesto)
  from.x <- from.uniq[-which(from.uniq %in% to.y)]

  # length of x and y variables
  n.x = length(from.x)
  n.y = length(to.y)

  # initiate SEM parameter matrix
  bma.gamma = matrix(0, ncol=n.x, nrow=n.y)
  colnames(bma.gamma) <- from.x
  rownames(bma.gamma) <- to.y
  bma.gamma

  bma.beta  = matrix(0, ncol=n.y, nrow=n.y)
  rownames(bma.beta) <- colnames(bma.beta) <- to.y
  bma.beta
  
  bma.alpha = rep(0, n.y) 
  names(bma.alpha) <- to.y
  bma.alpha

  bma.jita = rep(0, n.y)
  names(bma.jita) <- to.y
  bma.jita
  
  # names of parameters 
  parameters <- object$parameter
  para.list <- (strsplit(as.character(parameters), "~"))
  
#   id <- which(unlist(lapply(para.list, function(x) length(x)!=1)))
#   para.list <- para.list[id]
  
  para.list.to <- unlist(lapply(para.list, function(x) return(x[1]) ))
  para.list.from <- unlist(lapply(para.list, function(x) return(x[2]) ))
  
  # index of vectors for each matrix 
  id.gamma <- which(para.list.from %in% from.x)
  id.beta  <- which(para.list.from %in% to.y)
  id.alpha <- which(para.list.from %in% "1")
  id.jita  <- which(para.list.from %in% "")

  # assign coefficients from the BMA result to parameter matrix 
  {if (bma.model ==0)  coef <- object$postmean
  else coef <- object$coef[bma.model, ]}

  ## gamma matrix
  id.gamma
  for (i in 1:length(id.gamma))
  {
    col = para.list.from[id.gamma[i]]
    row = para.list.to[id.gamma[i]]
    bma.gamma[which(rownames(bma.gamma)==row), which(colnames(bma.gamma)==col)] <- coef[id.gamma[i]]
  }
  bma.gamma
  
  ## beta matrix
  id.beta
  for (i in 1:length(id.beta))
  {
    col = para.list.from[id.beta[i]]
    row = para.list.to[id.beta[i]]
    bma.beta[which(rownames(bma.beta)==row), which(colnames(bma.beta)==col)] <- coef[id.beta[i]]
  }
  bma.beta

  ## alpha matrix
  id.alpha  
  for (i in 1:length(id.alpha))
  {
    row = para.list.to[id.alpha[i]]
    bma.alpha[which(names(bma.alpha)==row)] <- coef[id.alpha[i]]
  }
  bma.alpha

  ## jita matrix
  id.jita  
  for (i in 1:length(id.jita))
  {
    row = para.list.to[id.jita[i]]
    bma.jita[which(names(bma.jita)==row)] <- coef[id.jita[i]]
  }
  bma.jita
  
  # Convert sem form to reduced form----------------------------------
  bma.inv.beta = as.matrix(solve(diag(n.y) - bma.beta))
  
  bma.pi0 = bma.inv.beta %*% as.matrix(bma.alpha)
  bma.pi1 = bma.inv.beta %*% bma.gamma
  bma.jitastar = bma.inv.beta %*% bma.jita
  
  # Predict ----------------------------------------------------------
  # test data
  x.obs.matrix <- as.matrix(newdata[, which(names(newdata) %in% from.x)])

  
  # for only last y variable
  last.y <- to.y[-which(to.y %in% from.uniq)]
  y3.obs <- (newdata[, match(last.y, names(newdata))])
  
  # parameter values for last y variable
  y3.bma.pi1 <- as.matrix(bma.pi1[match(last.y, rownames(bma.pi1)), ])
  y3.bma.pi0 <- bma.pi0[match(last.y, rownames(bma.pi0)), 1]
  
  y3.bma.pi <- matrix(c(y3.bma.pi0, y3.bma.pi1), ncol=1)


  # t value
  t.df <- object$lm.df
  t.p <- level + (1-level)/2
  t.value <-qt(t.p, t.df)

  mse=object$lm.mse


  predict.interval <- function(x.temp, ...)
  {
    x=c(1, x.temp) #row vector
    y.hat <- t(x) %*% y3.bma.pi
    r.term = (1 + t(x) %*%  object$lm.inv %*% x )
    r.term.1 = sqrt(mse * r.term )
    
    t.lwr <- y.hat - t.value * r.term.1
    t.upr <- y.hat + t.value * r.term.1
    
    return(cbind(fit=y.hat, lwr=t.lwr, upr=t.upr))
  }

  result = NULL
  for (i in 1:dim(x.obs.matrix)[1])
  {
    result = rbind(result, predict.interval(x.obs.matrix[i, ]))
  }


  result = data.frame(result)
  names(result) = c("fit", "lwr", "upr")
  return(result)
#   return(list(predict=result[, 1], lower=result[, 2], upper=result[, 3]))

}