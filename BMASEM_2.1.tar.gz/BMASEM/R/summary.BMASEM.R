#' Summaries of BMASEM object  
#'
#' predict.lad predicts new y observations for new x from the results of model fitting function, lad.
#' @param object  a model object (BMASEM) for which prediction is desired.
#' @param n.models optional number specifying the number of models to display in summary
#' @param ...  additional arguments affecting he predictions produced.
#' @return     No return values, instead it directly prints the summary. 
#' @details    The summary methods display a view specific to BMASEM.
#' @export
#' @examples
#' from.vars <- c("x1","x1","x2","x2","y1")
#' to.vars   <- c("y1","y2","y1","y2","y2")
#' start.link <- c(1, 0, 0, 1, 1) # an example
#' model <- BMASEM (from.vars, to.vars, data=train, start.link=start.link)
#' summary(model)
#' 

# function
summary.BMASEM <- function(object, n.models=10, ... )
{
  #Final results
  result <- data.frame(Parameters=c(object$parameter, "BIC", "PMP"))
  result <- cbind(result, Avg.coef = c(object$postmean, 0, 0))
  for (i in 1:min(length(object$model), n.models))
  { 
      temp.par <- c(unlist(object$coef[i, ]), object$bic[i], object$postprob[i])
      result <- cbind(result, temp.par)
      names(result)[i+2] <- object$model[i]
  }
  
  print(result) 
  return(invisible(object))
}
